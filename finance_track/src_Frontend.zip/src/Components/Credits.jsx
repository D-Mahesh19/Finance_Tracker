import React from 'react'
import {Link} from 'react-router-dom'

export default function Credits() {
  return (
    <div className='Credits-table'>
        <div className='data-btn'>
        <button className='btn1'><Link to='/Credits' className='link-cbtn'>Credit's Overview</Link></button>
        <button className='btn2'><Link to='/Debits' className='link-cbtn'>Debit's Overview</Link></button>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Credited Amount ₹</th>
                    <th>Subject</th>
                    <th>Payment Method</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>04-05-2024</td>
                        <td>7:01 PM</td>
                        <td>25,997</td>
                        <td>Salary</td>
                        <td>NEFT</td>
                    </tr>
                    <tr>
                        <td>11-05-2024</td>
                        <td>11:32 AM</td>
                        <td>6,400</td>
                        <td>Trading</td>
                        <td>PayPal</td>
                    </tr>
                    <tr>
                        <td>14-05-2024</td>
                        <td>3:49 PM</td>
                        <td>19,482</td>
                        <td>Bank Loan</td>
                        <td>UPI</td>
                    </tr>
                    <tr>
                        <td>-</td>
                        <td>-</td>
                        <td>2,300</td>
                        <td>Personal Savings</td>
                        <td>Cash</td>
                    </tr>
                </tbody>
                

            
        </table>
    </div>
  )
}
