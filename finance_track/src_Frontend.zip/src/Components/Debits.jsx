import React from 'react'
import { Link } from 'react-router-dom'

export default function Debits() {
  return (
    <div className='Debits-table'>
        <div className='data-btn'>
        <button className='btn1'><Link to='/Credits' className='link-cbtn'>Credit's Overview</Link></button>
        <button className='btn2'><Link to='/Debits' className='link-cbtn'>Debit's Overview</Link></button>
        </div>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Time</th>
                <th>Debited Amount ₹</th>
                <th>Subject</th>
                <th>Payment Method</th>
            </tr>
            </thead>
            <tbody>
                <tr>
                    <td>01-05-2024</td>
                    <td>10:01 AM</td>
                    <td>7,200</td>
                    <td> Rent</td>
                    <td>UPI</td>
                </tr>
                <tr>
                    <td>10-05-2024</td>
                    <td>1:32 PM</td>
                    <td>1,800</td>
                    <td>Grocery</td>
                    <td>Card</td>
                </tr>
                <tr>
                    <td>13-05-2024</td>
                    <td>12:49 PM</td>
                    <td>11,150</td>
                    <td>Shopping</td>
                    <td>UPI</td>
                </tr>
                <tr>
                    <td>23-05-2024</td>
                    <td>3:02 PM</td>
                    <td>8,350</td>
                    <td>Travel</td>
                    <td>Cash</td>
                </tr>
                <tr>
                    <td>-</td>
                    <td>-</td>
                    <td>799</td>
                    <td>Others</td>
                    <td>Cash</td>
                </tr>
            </tbody>
            

        
    </table>
</div>
  )
}
