import React from 'react'
import Paichart from './Paichart'
import axios from 'axios'
import Paichart1 from './Paichart1'


import { Form, Link } from 'react-router-dom'


export default function Layout() {
    const downloadCSV = async () => {
      try {
        const response = await axios.get('http://localhost:3000/Layout', {
          responseType: 'blob',
        });
  
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'data.csv');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (error) {
        console.error('There was an error downloading the CSV!', error);
      }
    };



  return (
    <div className='layout'>
      <div className='icons'>
      <div className='icons-left'>
      <i class="fa-solid fa-bars" ></i>
      <div className='menu-bar'>
      <button className='btnm1'><Link to='/Credits' className='link-cbtn'> Overview</Link></button>
      <button className='btnm1'><Link to='/Profile' className='link-cbtn'> Profile Edit</Link></button>
     
      </div>
      </div>
      <div className='icons-right'>
        <div className='fa ico'>
      <i class="fa-solid fa-circle-user"></i>
      <div className='user'>
      <button className='btnm1'><Link to='/LogIn' className='link-cbtn'>Log out</Link></button>
      <button className='btnm1'><Link to='/Help' className='link-cbtn'>Help</Link></button>
      <button className='btnm1'><Link to='/Contact' className='link-cbtn'>Contact Us</Link></button>
      </div>
      </div>
      <div className='fa fb'>
      <button onClick={downloadCSV}><i class="fa-solid fa-circle-arrow-down"></i></button>
      </div>
      </div>
      </div>
      <div className="layout-img">
        <img src="https://w7.pngwing.com/pngs/859/489/png-transparent-logo-accountant-accounting-consultant-design-text-service-logo.png" alt="" />
      </div>
        <div className='layout-data'>
        <div className='credit data'>
            <p>Credit's <br /> <i class="fa-solid fa-indian-rupee-sign"> 54,179</i></p>
            </div>
            <div className='debit data'>
            <p>Debit's <br /> <i class="fa-solid fa-indian-rupee-sign"> 29,299</i></p>
            </div>
            <div className='balance data'>
            <p>Balance <br /> <i class="fa-solid fa-indian-rupee-sign"> 24,880</i></p>
            </div>  
        </div>
        <div className='paichart'>
      
        
      

        <Paichart />
       {/* <Paichart1 />  */}
       
        </div>

    </div>
  )
}
