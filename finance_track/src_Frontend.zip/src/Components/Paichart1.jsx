import React, { useEffect, useState } from 'react';
import { Pie } from 'react-chartjs-2';
import axios from 'axios';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend);

const Paichart = () => {
  const [chartData, setChartData] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:3000/Paichart1')
      .then(response => {
        const data = response.data;

        const expenses = data.map(item => item.expenses);
        const amounts = data.map(item => item.amount);

        setChartData({
          labels: expenses,
          datasets: [
            {
              label: 'Expenses',
              data: amounts,
              backgroundColor: [
                '#254336',
                '#D2D2D2',
                '#F0AB00',
                '#009596',
                '#FF6384',
                '#36A2EB',
                '#FFCE56'
              ],
              borderWidth: 1,
            },
          ],
        });

        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
        setError(error.message);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div>
      <div className="chart-wrapper">
        <Pie data={chartData} />
      </div>
    </div>
  );
};

export default Paichart;
